import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
    private baseUrl = `${environment.apiBaseUrl}/account`;

  constructor(private http: HttpClient) {}

  googleLogin(idToken: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/google-login`, { idToken });
  }
}

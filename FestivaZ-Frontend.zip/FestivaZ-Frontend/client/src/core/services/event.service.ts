import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { EventCategory, EVENT_CATEGORIES } from '../../features/Guest/Events/events/events.data';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/api/events`;
  
  // Signal to track if we're using live data
  readonly isLiveData = signal<boolean>(false);
  
  /**
   * Fetch all events from API with mock data fallback
   * Returns mock data immediately via signal, then updates when API responds
   */
  getEvents(): Observable<EventCategory[]> {
    return this.http.get<EventCategory[]>(this.apiUrl).pipe(
      tap(() => this.isLiveData.set(true)),
      catchError(error => {
        console.warn('API unavailable, using mock data:', error.message);
        this.isLiveData.set(false);
        return of(EVENT_CATEGORIES);
      })
    );
  }

  /**
   * Fetch single event by ID from API with mock data fallback
   */
  getEventById(id: string): Observable<EventCategory | undefined> {
    return this.http.get<EventCategory>(`${this.apiUrl}/${id}`).pipe(
      tap(() => this.isLiveData.set(true)),
      catchError(error => {
        console.warn(`API unavailable for event ${id}, using mock data:`, error.message);
        this.isLiveData.set(false);
        const mockEvent = EVENT_CATEGORIES.find(e => e.id === id);
        return of(mockEvent);
      })
    );
  }

  /**
   * Get mock data synchronously (for initial state)
   */
  getMockEvents(): EventCategory[] {
    return EVENT_CATEGORIES;
  }
}

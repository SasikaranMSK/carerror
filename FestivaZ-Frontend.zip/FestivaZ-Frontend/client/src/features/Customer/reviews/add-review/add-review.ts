import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output, signal, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-add-review',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './add-review.html',
  styles: [`
  .review-modal { position: relative; padding: 1rem; max-width: 520px; background: #111; color: #eee; border-radius: 12px; box-shadow: 0 8px 24px rgba(0,0,0,.4); font-family: system-ui, Arial, sans-serif; }
  .review-modal .inner { display: flex; flex-direction: column; gap: 1rem; }
  .stars-picker { display: flex; gap: .5rem; }
  .stars-picker button { background: transparent; border: none; font-size: 1.75rem; cursor: pointer; color: #555; transition: color .2s, transform .2s; }
  .stars-picker button.active { color: gold; text-shadow: 0 0 6px rgba(255,215,0,.6); }
  .stars-picker button:focus-visible { outline: 2px solid gold; outline-offset: 2px; }
  textarea { width: 100%; border-radius: 8px; padding: .75rem; background: #1b1b1b; border: 1px solid #333; color: #eee; resize: vertical; min-height: 120px; }
  textarea:focus { outline: 2px solid #444; }
  .uploader input[type=file] { display: block; margin-top: .25rem; }
  .thumbs { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px,1fr)); gap: .5rem; }
  .thumbs img { width: 100%; height: 80px; object-fit: cover; border-radius: 6px; border: 1px solid #333; }
  .actions { display: flex; justify-content: flex-end; gap: .75rem; }
  .actions .btn-cancel, .actions .btn-submit { padding: .6rem 1.1rem; border-radius: 8px; font-weight: 600; cursor: pointer; border: none; }
  .actions .btn-cancel { background: #333; color: #ddd; }
  .actions .btn-cancel:hover { background: #444; }
  .actions .btn-submit { background: linear-gradient(135deg,#E9B949,#D97706); color: #111; }
  .actions .btn-submit:disabled { filter: grayscale(.6); cursor: not-allowed; opacity: .6; }
  .actions .btn-submit:not(:disabled):hover { filter: brightness(1.1); }
  .sr-only { position: absolute; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip:rect(0 0 0 0); white-space:nowrap; border:0; }
  `]
})
export class AddReviewComponent implements OnDestroy {
  @Output() cancel = new EventEmitter<void>();
  @Output() submitReview = new EventEmitter<{ rating: number; text: string; files: File[] }>();

  rating = signal<number>(0);
  text = signal<string>('');
  files = signal<File[]>([]);
  private objectUrlCache = new Map<File, string>();

  pick(files: FileList | null) {
    if (!files) return;
    const arr = Array.from(files).slice(0, 6); // cap 6 images
    this.files.set(arr);
  }

  setRating(n: number) { this.rating.set(n); }

  submit() {
    this.submitReview.emit({ rating: this.rating(), text: this.text(), files: this.files() });
  }

  objectURL(file: File): string {
    const cached = this.objectUrlCache.get(file);
    if (cached) return cached;
    const created = URL.createObjectURL(file);
    this.objectUrlCache.set(file, created);
    return created;
  }

  ngOnDestroy() {
    // Revoke all created object URLs to avoid memory leaks.
    for (const url of this.objectUrlCache.values()) {
      URL.revokeObjectURL(url);
    }
    this.objectUrlCache.clear();
  }
}

import { AfterViewInit, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { LoginCreds } from '../../../types/user';
import { AuthService } from '../../../core/services/auth-service';
import { environment } from '../../../environments/environment.development';
import { AccountService } from '../../../core/services/account.service';

declare const google: any; // ✅ must be outside the class

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login implements AfterViewInit{
  private accountService = inject(AccountService);

  protected creds: LoginCreds = { email: '', password: '' };
  protected loading = false;
  protected errorMsg = '';
  protected showPassword = false;

  submit() {
    if (!this.creds.email || !this.creds.password) {
      this.errorMsg = 'Email and password are required.';
      return;
    }
    this.loading = true;
    this.errorMsg = '';

    this.accountService.login(this.creds).subscribe({
      next: () => {
        this.loading = false;
      },
      error: (err: any) => {
        this.loading = false;
        this.errorMsg = err?.error || 'Login failed. Please try again.';
        console.error(err);
      },
    });
  }
    constructor(private authService: AuthService) {}


ngAfterViewInit(): void {
  google.accounts.id.initialize({
    client_id: environment.googleClientId,
    callback: (response: any) => this.handleCredentialResponse(response)
  });
}

signInWithGoogle(): void {
  google.accounts.id.prompt(); // shows the popup
}

private handleCredentialResponse(response: any): void {
  const idToken = response.credential; // JWT token
  if (!idToken) return console.error('No credential received');

  this.authService.googleLogin(idToken).subscribe({
    next: (res) => console.log('✅ Google login success', res),
    error: (err) => console.error('❌ Google login failed', err)
  });
}

}

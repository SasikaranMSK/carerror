import { Routes } from '@angular/router';
import { Login } from '../features/account/login/login';
import { Register } from '../features/account/register/register';
import { Events } from '../features/Guest/Events/events/events';
import { EventDetails } from '../features/Guest/Events/events/details/event-details';
import { About } from '../features/Guest/About/about/about';
import { Contact } from '../features/Guest/Contacts/contact/contact';

import { CreateEvent } from '../features/Guest/CreateEvent/create-event/create-event';
import { Home } from '../features/Common/home/home';

export const routes: Routes = [

    { path: '', component: Home },
    { path: 'login', component: Login },
    { path: 'register', component: Register },
    { path: 'contact', component: Contact },
    { path: 'about', component: About },
    { path: 'events', component: Events },
    { path: 'events/:id', component: EventDetails },
    { path: 'create-event', component: CreateEvent },
    { path: '**', component: Home },

];

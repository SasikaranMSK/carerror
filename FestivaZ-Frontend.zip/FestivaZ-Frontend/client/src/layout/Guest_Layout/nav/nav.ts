import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AccountService } from '../../../core/services/account.service';
import { User } from '../../../types/user';

@Component({
  selector: 'app-nav',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive],
  templateUrl: './nav.html',
  styleUrls: ['./nav.css'],
})
export class Nav {
  protected accountService = inject(AccountService);

  protected creds: { username?: string; password?: string } = {};
  protected isMenuOpen = signal(false);

  // ✅ Getter for template safety
  get currentUser(): User | null {
    return this.accountService.currentUser();
  }

  toggleMenu(): void {
    this.isMenuOpen.update(open => !open);
  }

  closeMenu(): void {
    this.isMenuOpen.set(false);
  }

  login(): void {
    this.accountService.login(this.creds).subscribe({
      next: (result: User) => {
        console.log('Login successful:', result);
        this.creds = {};
        this.closeMenu();
      },
      error: (err: any) => console.error('Login error:', err.message || err),
    });
  }

  logout(): void {
    this.accountService.logout();
    this.closeMenu();
  }
}

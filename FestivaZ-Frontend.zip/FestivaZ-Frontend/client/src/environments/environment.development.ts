export const environment = {
  production: false,
  apiUrl: 'http://localhost:5077', // Your ASP.NET backend URL
  googleClientId: '732717088288-vrbfddmegpr076h0e9f7lear2ibdldhr.apps.googleusercontent.com',
  apiBaseUrl: 'http://localhost:5077/api' // your backend
};

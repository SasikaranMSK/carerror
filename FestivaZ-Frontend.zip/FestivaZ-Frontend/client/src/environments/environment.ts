export const environment = {
  production: true,
  apiUrl: 'https://your-production-api-url.com', // Update with your production API URL
  googleClientId: '732717088288-vrbfddmegpr076h0e9f7lear2ibdldhr.apps.googleusercontent.com'
};
